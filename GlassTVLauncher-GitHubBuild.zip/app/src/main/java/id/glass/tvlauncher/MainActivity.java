package id.glass.tvlauncher;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;

public class MainActivity extends Activity {
    private static final int PICK_WALLPAPER = 71;
    private final Handler handler = new Handler();
    private TextView clock, date, prayerText, nextPrayer;
    private ImageView background;
    private Runnable ticker;
    private final String[] prayerNames = {"Subuh", "Terbit", "Zuhur", "Asar", "Magrib", "Isya"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        buildUi(); restoreWallpaper(); refreshClockAndPrayer();
        ticker = new Runnable() { public void run() {
            refreshClockAndPrayer(); handler.postDelayed(this, 1000);
        }};
        handler.post(ticker);
    }

    private void buildUi() {
        FrameLayout frame = new FrameLayout(this);
        background = new ImageView(this);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        background.setBackgroundColor(Color.rgb(18,27,43));
        frame.addView(background, new FrameLayout.LayoutParams(-1,-1));
        View shade = new View(this); shade.setBackgroundColor(0x99091424);
        frame.addView(shade, new FrameLayout.LayoutParams(-1,-1));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(58,34,58,30);
        frame.addView(root, new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL); top.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(top, new LinearLayout.LayoutParams(-1,0,1.2f));
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
        top.addView(left, new LinearLayout.LayoutParams(0,-1,1.4f));
        left.addView(makeText("GLASS TV",18,0xFFE5EDF8,true));
        clock = makeText("--:--:--",66,Color.WHITE,true);
        clock.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL)); left.addView(clock);
        date = makeText("",20,0xFFE2EAF4,false); left.addView(date);
        LinearLayout right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER); right.setPadding(25,20,25,20);
        right.setBackgroundColor(0x66313F53);
        top.addView(right,new LinearLayout.LayoutParams(0,-1,0.85f));
        right.addView(makeText("JADWAL SHOLAT",20,Color.WHITE,true));
        right.addView(makeText("KOTA TEGAL",13,0xFFD5E0EE,false));
        prayerText = makeText("",18,Color.WHITE,false); prayerText.setLineSpacing(8,1f);
        right.addView(prayerText);
        nextPrayer = makeText("",15,0xFFFFD27A,true); right.addView(nextPrayer);
        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL); bottom.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(bottom,new LinearLayout.LayoutParams(-1,72));
        Button wallpaper = new Button(this); wallpaper.setText("GANTI WALLPAPER");
        wallpaper.setTextSize(14); wallpaper.setFocusable(true);
        wallpaper.setOnClickListener(v -> chooseWallpaper()); bottom.addView(wallpaper);
        bottom.addView(makeText("  OK: pilih wallpaper  •  HOME: kembali ke launcher",14,0xFFE1E8F0,false));
        setContentView(frame); wallpaper.requestFocus();
    }

    private TextView makeText(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private void chooseWallpaper() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK_WALLPAPER);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==PICK_WALLPAPER && result==RESULT_OK && data!=null) {
            Uri uri=data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
                getPreferences(0).edit().putString("wallpaper",uri.toString()).apply();
                showWallpaper(uri);
            } catch(Exception e) { Toast.makeText(this,"Wallpaper gagal dibuka",Toast.LENGTH_SHORT).show(); }
        }
    }
    private void restoreWallpaper() {
        String saved=getPreferences(0).getString("wallpaper",null);
        if(saved!=null) showWallpaper(Uri.parse(saved));
    }
    private void showWallpaper(Uri uri) {
        try {
            InputStream in=getContentResolver().openInputStream(uri);
            Bitmap bmp=BitmapFactory.decodeStream(in); if(in!=null) in.close();
            if(bmp!=null) background.setImageBitmap(bmp);
        } catch(Exception ignored) {}
    }
    private void refreshClockAndPrayer() {
        Date now=new Date(); Locale id=new Locale("id","ID");
        clock.setText(new SimpleDateFormat("HH:mm:ss",id).format(now));
        date.setText(new SimpleDateFormat("EEEE, dd MMMM yyyy",id).format(now));
        double[] times=PrayerCalculator.calculate(now,-6.87,109.14,7.0);
        StringBuilder b=new StringBuilder();
        for(int n=0;n<prayerNames.length;n++) {
            b.append(String.format(Locale.US,"%-8s  %s",prayerNames[n],PrayerCalculator.format(times[n])));
            if(n<prayerNames.length-1) b.append("\\n");
        }
        prayerText.setText(b.toString());
        Calendar cal=Calendar.getInstance();
        int current=cal.get(Calendar.HOUR_OF_DAY)*60+cal.get(Calendar.MINUTE);
        String next="Subuh";
        for(int n=0;n<times.length;n++) {
            int minute=(int)Math.round(times[n]*60);
            if(minute>current) { next=prayerNames[n]; break; }
        }
        nextPrayer.setText("Jadwal berikutnya: "+next);
    }
    @Override protected void onDestroy() {
        super.onDestroy(); if(ticker!=null) handler.removeCallbacks(ticker);
    }
}
