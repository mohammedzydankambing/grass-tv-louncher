package id.glass.tvlauncher;
import java.util.Locale;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/* Estimasi astronomis: Subuh 20°, Isya 18°, Asar standar.
   Cocokkan dengan jadwal resmi Kemenag/masjid setempat. */
public class PrayerCalculator {
    static double[] calculate(Date date,double lat,double lon,double tz) {
        Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Jakarta"));
        c.setTime(date); int day=c.get(Calendar.DAY_OF_YEAR);
        double lngHour=lon/15.0;
        double decl=23.45*Math.sin(Math.toRadians(360.0*(284+day)/365.0));
        double B=Math.toRadians(360.0*(day-81)/364.0);
        double E=9.87*Math.sin(2*B)-7.53*Math.cos(B)-1.5*Math.sin(B);
        double solarNoon=12+tz-lngHour-E/60.0;
        double noonAngle=hourAngle(lat,decl,0);
        double sunrise=solarNoon-noonAngle/15.0, sunset=solarNoon+noonAngle/15.0;
        double fajr=solarNoon-hourAngle(lat,decl,-20)/15.0;
        double isha=solarNoon+hourAngle(lat,decl,-18)/15.0;
        double asrAlt=Math.toDegrees(Math.atan(1.0/(1.0+Math.tan(Math.toRadians(Math.abs(lat-decl))))));
        double asr=solarNoon+hourAngle(lat,decl,asrAlt)/15.0;
        return new double[]{fajr,sunrise,solarNoon,asr,sunset,isha};
    }
    private static double hourAngle(double lat,double decl,double altitude) {
        double x=(Math.sin(Math.toRadians(altitude))-Math.sin(Math.toRadians(lat))*Math.sin(Math.toRadians(decl)))/
            (Math.cos(Math.toRadians(lat))*Math.cos(Math.toRadians(decl)));
        x=Math.max(-1,Math.min(1,x)); return Math.toDegrees(Math.acos(x));
    }
    static String format(double hours) {
        int mins=(int)Math.round(hours*60); mins=(mins%1440+1440)%1440;
        return String.format(Locale.US,"%02d:%02d",mins/60,mins%60);
    }
}
